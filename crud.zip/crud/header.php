<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Page</title>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- Font Awesome Icon -->
    <link rel="stylesheet" href="css/font-awesome.css">
    <!-- Custom stlylesheet -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <!-- HEADER -->
    <div id="header-admin">
        <!-- container -->
        <div class="container">
            <!-- row -->
            <div class="row">
                <div class="col-12">
                </div>
                <div class="col text-center">

                    <div class="admin-logout"> CRUD Opertions</div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- /HEADER -->
    <!-- Menu Bar -->
    <div id="admin-menubar">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ul class="admin-menu">
                        <li>
                            <a href="index.php">Records</a>
                        </li>
                        <li>
                        <a href='postdata.php'>Show Json</a>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <?php

?>
    <!-- /Menu Bar -->